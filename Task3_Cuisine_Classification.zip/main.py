import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import classification_report

df = pd.read_csv('cuisine_data.csv')
le_cuisine = LabelEncoder()
df['cuisine'] = le_cuisine.fit_transform(df['cuisine'])

# Feature encoding
df['ingredients'] = df['ingredients'].astype('category').cat.codes

X = df[['ingredients', 'price_range', 'service_rating']]
y = df['cuisine']

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

clf = RandomForestClassifier()
clf.fit(X_train, y_train)

y_pred = clf.predict(X_test)
print(classification_report(y_test, y_pred, target_names=le_cuisine.classes_))
